See our api docs https://node-serialport.github.io/node-serialport/CCTalkParser.html
